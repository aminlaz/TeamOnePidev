<?php

namespace UserBundle\Controller;

use ProfilingBundle\Entity\Badge;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use UserBundle\Entity\User;

class UserController extends Controller
{


}
